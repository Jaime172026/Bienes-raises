public class Propiedad {
    private int idPropiedad;
    private String titulo;
    private String descripcion;
    private double precio;
    private String ubicacion;
    private String tipo; // Casa, Departamento, Terreno
    private String estado; // Disponible, Vendida, Rentada

    public Propiedad() {}

    public Propiedad(int idPropiedad, String titulo, String descripcion, double precio, String ubicacion, String tipo, String estado) {
        this.idPropiedad = idPropiedad;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.precio = precio;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
        this.estado = estado;
    }

    public void mostrarInformacion() {
        System.out.println("Propiedad: " + titulo + " | Ubicación: " + ubicacion + " | Precio: $" + precio);
    }

    public void actualizarEstado(String nuevoEstado) {
        this.estado = nuevoEstado;
        System.out.println("El estado de la propiedad se actualizó a: " + this.estado);
    }

    public String getTitulo() { return titulo; }
    public String getUbicacion() { return ubicacion; }
    public double getPrecio() { return precio; }
}