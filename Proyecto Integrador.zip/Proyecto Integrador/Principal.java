public class Principal {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE GESTIÓN INMOBILIARIA Y EVALUACIÓN DIGITAL ===");
        System.out.println("Universidad Politécnica Salesiana - Proyecto Integrador\n");

        Cliente cliente1 = new Cliente(1, "Alejandro", "Pérez", "0991234567", "alejandro@email.com", "Av. Solano");
        Agente agente1 = new Agente(1, "Carlos Daniel", "0987654321", "carlos@inmobiliaria.com", "Bienes Raíces Comerciales");
        Propiedad propiedad1 = new Propiedad(101, "Oficina Moderna", "Oficina con vista a la ciudad", 85000.0, "Cuenca, Sector El Ejido", "Departamento", "Disponible");
        Venta venta1 = new Venta(1001, "2026-05-31", 85000.0, "Completada");

       
        System.out.println("--- Operaciones del Negocio ---");
        cliente1.registrarse();
        agente1.gestionarCliente(cliente1);
        propiedad1.mostrarInformacion();
        propiedad1.actualizarEstado("Vendida");
        venta1.generarVenta();

    
        EvaluacionMadurezDigital evaluacion = new EvaluacionMadurezDigital(1, "2026-05-31", 90, 85, 70, 60);
        IndicadorDigital indicador1 = new IndicadorDigital(1, "Adopción de CRM", "Porcentaje de clientes ingresados vía web", 85, 80);
        IndicadorDigital indicador2 = new IndicadorDigital(2, "Firma Electrónica", "Contratos firmados digitalmente", 45, 75);

      
        System.out.println("\n--- Evaluación de Madurez Digital ---");
        System.out.println("Promedio de Madurez Digital: " + evaluacion.calcularPromedio() + "%");
        System.out.println("Nivel General: " + evaluacion.obtenerNivelMadurezDigital());
        
        System.out.println("\n--- Panel de Indicadores (Dashboard) ---");
        indicador1.mostrarEstadoIndicador();
        indicador2.mostrarEstadoIndicador();
    }
}