public class IndicadorDigital {
    private int idIndicador;
    private String nombre;
    private String descripcion;
    private double valorActual;
    private double valorObjetivo;

    public IndicadorDigital() {}

    public IndicadorDigital(int idIndicador, String nombre, String descripcion, double valorActual, double valorObjetivo) {
        this.idIndicador = idIndicador;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.valorActual = valorActual;
        this.valorObjetivo = valorObjetivo;
    }

    public boolean estaCumplido() {
        return valorActual >= valorObjetivo;
    }

    public void mostrarEstadoIndicador() {
        String estado = estaCumplido() ? "CUMPLIDO" : "NO CUMPLIDO";
        System.out.println("Indicador: " + nombre + " | Estado: " + estado + " (" + valorActual + "/" + valorObjetivo + ")");
    }
}