public class Cliente {
    private int idCliente;
    private String nombre;
    private String apellido;
    private String telefono;
    private String correo;
    private String direccion;

   
    public Cliente() {}


    public Cliente(int idCliente, String nombre, String apellido, String telefono, String correo, String direccion) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.correo = correo;
        this.direccion = direccion;
    }


    public void registrarse() {
        System.out.println("El cliente " + this.nombre + " " + this.apellido + " ha sido registrado en el sistema CRM.");
    }

    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
}