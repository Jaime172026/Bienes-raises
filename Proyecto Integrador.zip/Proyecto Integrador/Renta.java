public class Renta {
    private int idRenta;
    private String fechaInicio;
    private String fechaFin;
    private double valorMensual;
    private String estado;

    public Renta() {}

    public Renta(int idRenta, String fechaInicio, String fechaFin, double valorMensual, String estado) {
        this.idRenta = idRenta;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.valorMensual = valorMensual;
        this.estado = estado;
    }

    public void generarContrato() {
        System.out.println("Contrato de renta generado desde " + fechaInicio + " hasta " + fechaFin);
    }
}