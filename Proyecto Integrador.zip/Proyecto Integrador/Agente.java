public class Agente {
    private int idAgente;
    private String nombre;
    private String telefono;
    private String correo;
    private String especialidad;

    public Agente() {}

    public Agente(int idAgente, String nombre, String telefono, String correo, String especialidad) {
        this.idAgente = idAgente;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.especialidad = especialidad;
    }

    public void gestionarCliente(Cliente cliente) {
        System.out.println("El agente " + this.nombre + " está gestionando al cliente " + cliente.getNombre());
    }

    public String getNombre() { return nombre; }
}