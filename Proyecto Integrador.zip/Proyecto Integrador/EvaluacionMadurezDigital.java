public class EvaluacionMadurezDigital {
    private int idEvaluacion;
    private String fechaEvaluacion;
    private double puntajeCRM;
    private double puntajeMarketingDigital;
    private double puntajeAutomatizacion;
    private double puntajeFirmaElectronica;


    public EvaluacionMadurezDigital() {}

  
    public EvaluacionMadurezDigital(int idEvaluacion, String fechaEvaluacion, double puntajeCRM, double puntajeMarketingDigital, double puntajeAutomatizacion, double puntajeFirmaElectronica) {
        this.idEvaluacion = idEvaluacion;
        this.fechaEvaluacion = fechaEvaluacion;
        this.puntajeCRM = puntajeCRM;
        this.puntajeMarketingDigital = puntajeMarketingDigital;
        this.puntajeAutomatizacion = puntajeAutomatizacion;
        this.puntajeFirmaElectronica = puntajeFirmaElectronica;
    }

  
    public double calcularPromedio() {
        return (puntajeCRM + puntajeMarketingDigital + puntajeAutomatizacion + puntajeFirmaElectronica) / 4;
    }


    public String obtenerNivelMadurezDigital() {
        double promedio = calcularPromedio();
        if (promedio >= 80) {
            return "Alto - Nivel PropTech Avanzado";
        } else if (promedio >= 50) {
            return "Medio - En proceso de Transformación";
        } else {
            return "Bajo - Requiere Digitalización Urgente";
        }
    }
}