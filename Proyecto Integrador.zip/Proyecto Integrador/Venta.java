public class Venta {
    private int idVenta;
    private String fechaVenta;
    private double monto;
    private String estado;

    public Venta() {}

    public Venta(int idVenta, String fechaVenta, double monto, String estado) {
        this.idVenta = idVenta;
        this.fechaVenta = fechaVenta;
        this.monto = monto;
        this.estado = estado;
    }

    public void generarVenta() {
        System.out.println("Venta procesada con éxito por un monto de: $" + this.monto);
    }
}